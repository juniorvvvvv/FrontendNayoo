<!DOCTYPE html>
<html lang="en">
<head>


<!-- <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->


    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- มาก็ดิครับ -->
        <meta name="csrf-token" content="{{ csrf_token() }}" />

        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="{{asset('js/jquery-3.6.0.js')}}" integrity="" crossorigin="anonymous" ></script>
        <script src="{{asset('js/bootstrap.min.js')}}" integrity="" crossorigin="anonymous"></script>

    </head>

    <title></title>
    <style>
  
    </style>

</head>
<body>
    <div class="container-fluid border">
        <div class="row">
            <div class="col-2">

            </div>
            <div class="col-8">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg font-weight" >
                        <div class="container-fluid">

                            <a class="navbar-brand text-dark" href="#">LOGO</a>


                                <input class="form-control  w-100 h-10" type="search" placeholder="ค้นหา" aria-label="Search" ">

                        </div>
                        <div class="container-fluid">
                            <div class="collapse navbar-collapse" id="navbarNav">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                    <a class="nav-link text-dark" href="#">หน้าแรก</a>
                                    </li>
                                    <li class="nav-item">
                                    <a class="nav-link text-dark" href="#">เกี่ยวกับ</a>
                                    </li>
                                    <li class="nav-item">
                                    <a class="nav-link text-dark" href="#" tabindex="-1" aria-disabled="true">ติดต่อ</a>
                                    </li>
                                </ul>
                            </div>
                            <button class="btn btn-outline-dark btn-secondary me-2 "type="submit">Register</button>
                            <button class="btn btn-outline-dark me-2" type="submit">Sign In</button>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="col-2">
        </div>
    </div>

    <div class="border">

        <div class="container-fulid" style="height:320px;">
            <div class="row">
                <div class="col-3">

                <div class="container-fluid">
                    <div class="row board-container float-start fixed-top">
                        <div class="board" id="modalwindow1">
                            <button type="submit" class="btn1 btn-danger" id="closemodal" onclick="closemodal1()">

                            <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi1 bi-x-circle-fill" viewBox="0 0 16 16"
                                >
                                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                            </svg>
                            </button>
                        </div>
                    </div>
                </div>


                </div>
                <div class="col-6">

                    <h1 class="text-center">ชื่อหน้าเว็บไซต์</h1>

                    <div id="carouselExampleIndicators" class="carousel slide " data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner" style="height:15rem">
                            <div class="carousel-item active">
                                <img src="11.png" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="12.png" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="13.png" class="d-block w-100" alt="...">
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>


                    </div>
                </div>
                <div class="col-3">

                    <div class="container-fluid" style=" position: fixed; left: 0px; top:45px;">
                        <div class="row board-container float-end ">
                            <div class="board" id="modalwindow2">
                                <button type="submit" class="btn1 btn-danger" id="closemodal" onclick="closemodal2()">
                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi1 bi-x-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                                </svg>
                                </button>

                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </div>

        <div class="container-fulid" style="height: 300px;">
            <div class="row">
                <div class="col-3">
                </div>
                <div class="col-6">

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-4">
                                <img src="images/2.png" class="card-img-top " alt="..." style="border-radius: 20px; ">
                            </div>
                            <div class="col-4">
                                <img src="1.png" class="card-img-top" alt="..." style="border-radius: 20px; ">
                            </div>
                            <div class="col-4">
                                <img src="3.png" class="card-img-top" alt="..." style="border-radius: 20px; ">
                            </div>
                        </div>
                    </div>

                    <!-- .board-container2{padding:40px;box-sizing:border-box;height: 200px; width: 500px; top: 40px;} -->

                        <div class="container-fluid2" style="position: fixed;" >
                                <div class="row board-container2 "  >
                                    <div class="board" id="modalwindow3">
                                    <button type="submit" class="btn2 btn-danger" id="closemodal" onclick="closemodal3()">ปิด

                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                                        </svg>
                                    </button>

                                </div>
                        </div>

                            <!--
                        <button type="button" class="close float-start " data-dismiss="modal" >

                            <span aria-hidden="true" class="modal_button">&times;
                            </span>

                            <span class="sr-only">

                            </span>
                            </button> -->

                    </div>

                </div>
                <div class="col-3">
                </div>
            </div>


        </div>


        <div class="container-fulid" style="height: 400px;">
            <div class="row">
                <div class="col-3">
                </div>
                <div class="col-6">

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-6">
                                <h2>โครงการแนะนำ </h2>
                            </div>
                            <div class="col-6">
                                <h3 style="text-align:right" >
                                    ดูทั้งหมด
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                                    </svg>
                                </h3>

                            </div>
                        </div>
                    </div>

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-3">
                                <div class="card " style="width: 14rem; height: 22rem;">
                                    <img src="11.png" class="card-img-top" alt="..." style="height: 25rem;">
                                    <div class="card-body">
                                        <h7 class="card-title">Card title</h7>
                                        <h6 class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">ราคาเริ่มต้น</h6>
                                        <h6  class="card-text">฿ 9,999,999 </h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card " style="width: 14rem; height: 22rem;">
                                    <img src="12.png" class="card-img-top" alt="..." style="height: 25rem;">
                                    <div class="card-body">
                                        <h7 class="card-title">Card title</h7>
                                        <h6 class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">ราคาเริ่มต้น</h6>
                                        <h6  class="card-text">฿ 9,999,999 </h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card " style="width: 14rem; height: 22rem;">
                                    <img src="13.png" class="card-img-top" alt="..." style="height: 25rem;">
                                    <div class="card-body">
                                        <h7 class="card-title">Card title</h7>
                                        <h6 class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">ราคาเริ่มต้น</h6>
                                        <h6  class="card-text">฿ 9,999,999 </h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">

                                <div class="card " style="width: 14rem; height: 22rem;">
                                    <img src="14.png" class="card-img-top" alt="..." style="height: 25rem;">
                                    <div class="card-body">
                                        <h7 class="card-title">Card title</h7>
                                        <h6 class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">Lorem Ipsum is simply</h6>
                                        <h6  class="card-text">ราคาเริ่มต้น</h6>
                                        <h6  class="card-text">฿ 9,999,999 </h6>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>


                </div>
                <div class="col-3">
                </div>
            </div>
        </div>

        <div class="container-fulid" style="height: 400px;">
            <div class="row">
                <div class="col-3">
                </div>
                <div class="col-6">

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-6">
                                    <h2>โครงการเปิดตัวเร็ว ๆ นี้ </h2>
                            </div>
                            <div class="col-6">
                            </div>
                        </div>
                    </div>

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-6">

                                    <div class="col">
                                        <div class="card">
                                            <img src="15.png" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title">Card title</h5>
                                                <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                            </div>
                                        </div>
                                    </div>

                            </div>
                            <div class="col-6">
                                    <div class="col">
                                        <div class="card">
                                            <img src="16.png" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                    <h5 class="card-title">Card title</h5>
                                                    <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                            </div>
                                        </div>
                                    </div>


                            </div>
                        </div>
                    </div>


                </div>

                <div class="col-3">
                </div>



            </div>
        </div>

        <div class="container-fulid" style="height: 400px;">
            <div class="row">
                <div class="col-3">
                </div>

                <div class="col-6">

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-8">
                                    <h2>ทรัพย์สินรอการขาย (NPA)</h2>
                            </div>
                            <div class="col-4">

                                <h3 style="text-align:right" >
                                    ดูทั้งหมด
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                                    </svg>
                                </h3>

                            </div>
                        </div>
                    </div>

                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-3" >

                                    <img src="17.png" class="card-img-top" alt="..." >
                                <!-- <div class="position-absolute top-50 start-50 translate-middle"> -->
                                    <img src="21.png" id="zzz" class="card-img-top top-50 start-50" alt="...">
                                <!-- </div> -->
                            </div>
                            <div class="col-3">

                                    <img src="18.png" class="card-img-top float" alt="..." >

                            </div>
                            <div class="col-3">

                                    <img src="19.png" class="card-img-top" alt="..." >

                            </div>
                            <div class="col-3">

                                    <img src="20.png" class="card-img-top" alt="..." >

                            </div>
                        </div>
                    </div>


                </div>

                <div class="col-3">
                </div>



            </div>
        </div>

        <div class="container-fulid" style="height: 400px;">
            <div class="row">

                <div class="col-1">
                </div>

                <div class="col-5">
                    <h3>Contact Us</h3>
                    <label for="">  099-9999-999</label><br>
                    <label for=""> Test@gmail.com</label>


                </div>

                <div class="col-6"  style="padding-left: 5em">
                    <strong> Terms & Conditions</strong>
                    <strong>
                    Privacy Policy</strong>
                    <strong>  <strong>   Cookie Policy</strong>



                </div>
            </div>
        </div>

    </div>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="{{asset('js/jquery-3.6.0.js')}}" integrity="" crossorigin="anonymous" ></script>


<script type="text/javascript">
    function closemodal1(){
        $('#modalwindow1').hide();
    }

    function closemodal2(){
        $('#modalwindow2').hide();
    }

    function closemodal3(){
        $('#modalwindow3').hide();
    }
</script>
