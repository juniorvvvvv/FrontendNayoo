function closemodal1(){
    $('#modalwindow1').hide();
}

function closemodal2(){
    $('#modalwindow2').hide();
}

function closemodal3(){
    $('#modalwindow3').hide();
}